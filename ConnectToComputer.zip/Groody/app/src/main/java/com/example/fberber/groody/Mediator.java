package com.example.fberber.groody;

public class Mediator {

    public static int med ;
    public static String ipcontrol;
    public static int ipflag ;
    public static int brightness;
    public static String ip ;
    public static int port;


    public  Mediator(){

    }
}
